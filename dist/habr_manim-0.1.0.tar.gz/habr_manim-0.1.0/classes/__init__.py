__version__ = '0.1.0'

from .hist_and_funnel import HistAndFunnel
